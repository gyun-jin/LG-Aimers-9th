# TabM v1 (LG Aimers 9기)

팀 공유용 단일 TabM 후보입니다. 외부 데이터/사전학습 가중치는 사용하지 않습니다.
공식 `tabm` 패키지의 TabM(`k=16`, 3 blocks, width 256) 하나를 사용합니다.
TabM 내부의 16개 예측 head는 아키텍처 자체이며 별도 모델 앙상블이 아닙니다.

## 설계

- 입력: 공식 `train.csv` / `test.csv`의 현재 투구 직전 정보만 사용
- 피처: 원본 as-of 피처 + 행 단위 v4/v6 상호작용
- 전처리: 수치 결측 중앙값, 표준화, 32-bin piecewise-linear embeddings
- 범주형: 상태/선수/팀 ID one-hot, 미지 범주는 전용 unknown slot
- 검증: 2019-2023 학습 -> 2024 검증, Brier score 조기 종료
- 최종: 선택된 epoch 수만큼 2019-2024 전체 데이터로 새로 학습
- 출력: `control_success=1` 확률. TabM의 16개 확률 평균

## 빠른 실행 (L4 GPU 권장)

```bash
cd candidates/tabm_v1
pip install -r requirements.txt
python train.py
python script.py --input ../../data/test.csv --output output/submission.csv
```

빠른 확인만 할 경우 최종 전체 재학습을 생략할 수 있습니다.

```bash
python train.py --smoke
```

CPU fallback은 지원하지만 147만 행 학습은 매우 느리므로 GPU를 권장합니다.

## 팀원에게 보낼 파일

학습 전에는 이 폴더 전체를 전달합니다. 학습 후 제출 추론용으로는 아래만 필요합니다.

```text
common.py
tabm_model.py
script.py
requirements.txt
model/
  tabm.pt
  preprocessor.json
  report.json
```

`model/report.json`에 2024 Brier, 선택 epoch, seed가 기록됩니다.
